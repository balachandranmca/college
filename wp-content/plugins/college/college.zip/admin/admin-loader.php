<?php

/*
 *   include all the admin page files here
 */

include_once 'page_setting.php';
