<?php 

namespace App;

use Illuminate\Database\Eloquent\Model as Eloquent;

class JournalEditor extends Eloquent

{
    protected $table = 'journal_editors';

    protected $primaryId = 'id';

    protected $fillable = [
                            'image',
                            'type',
                            'name',
                            'qualification',
                            'job_nature',
                            'experience',
                            'department',
                            'place',
                            'city_country',
                            'emailid',
                            'mobile_no',
                            'journal_id'
                          ];

}