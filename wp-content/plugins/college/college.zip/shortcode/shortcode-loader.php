<?php
/*
 *  Loader for all the shortcode files
 */

include_once 'college_demo.php';

include_once 'college_login.php';

include_once 'college_journal.php';

include_once 'college_about_us.php';

include_once 'college_contact_us.php';

include_once 'college_slider.php';

include_once 'college_slider_list.php';

include_once 'college_journal_list.php';

include_once 'college_volume.php';

include_once 'college_volume_list.php';

include_once 'college_issue.php';

include_once 'college_issue_list.php';

include_once 'college_call_for_paper.php';

include_once 'college_editor.php';

include_once 'college_editor_list.php';

include_once 'college_journal_editor.php';

include_once 'college_journal_editor_list.php';

include_once 'college_editor_board.php';

include_once 'college_processing_fees.php';

include_once 'college_editor_board.php';


include_once 'college_general_settings.php';

include_once 'college_journal_view.php';

include_once 'college_carosel_slider.php';

include_once 'college_carosel_slider_list.php';