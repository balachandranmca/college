<div class="container journal-editors-listpage">
    <div class="row">
        <div class="col-md-12 content">
            <div class="row">
                <div class="col-md-12 create-new-btn">
                    <div class="pull-right">
                        <a href="<?php echo get_buzz_url('college_journal_editor');?>"><button type="button" class="btn btn-primary">Create New</button></a>
                    </div>
                </div>
            </div>
            <div class="row" style="margin-top:20px;">
                <div class="col-md-12 content-table">
                    <div class="table-responsive journal_editor-listpage">
                        <table id="mytable" class="table table-bordred table-striped">
                            <thead>
                                <th>Image</th>
                                <th>Journal</th>
                                <th>Editor Type</th>
                                <th>Edit</th>
                                
                                <th>Delete</th>
                            </thead>
                            <tbody>
                            <?php foreach ($journal_editorList as $key => $value) { ?>
                                <tr>
                                <?php 
                                   $image =  json_decode($value['image'],1);
                                ?>
                                <td><img class="journal_editor-list-img slider-list-img" src="<?php echo $image['url'];?>" alt="List-img"></td>
                                <td><?php echo $journal[$value['journal_id']];?></td>
                                <td><?php echo get_editor_type($value['type']);?></td>
                                <td><p data-placement="top" data-toggle="tooltip" title="Edit"><a href="<?php echo get_buzz_url('college_journal_editor').'?id='.$value['id'];?>"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></a></p></td>
                                <td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="delete btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-id="<?php echo $value['id'];?>" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
                                </tr>
                            <?php } ?>  
                            </tbody>
                        </table>
                            <div class="clearfix"></div>                
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
     jQuery(document).on('click', '.delete', function(e){
        e.preventDefault();
        var result = confirm("Are you sure to delete?");
        if(result) {
            var journal_editorid = jQuery(this).attr('data-id');
            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    'action':'college_journal_editor_delete',
                    'journal_editorid' : journal_editorid,
                },
                success:function(response) {
                    window.location = "<?php echo get_buzz_url('college_journal_editor_list');?>";
                }
            });
        }
     });
</script>