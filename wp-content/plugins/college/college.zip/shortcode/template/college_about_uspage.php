<section class="aboutus-page">
    <div class="row">
        <div class="col-md-6">
            <img class="slider-list-img" src="<?php echo site_url();?>/wp-content/themes/twentyfourteen/images/rsz_1book1.png" alt="List-img">
        </div>
        <div class="col-md-6 content">
            <h2>International Journal of Research in Engineering, Science and Technologies (IJRESTs)</h2>
            <?php echo get_option('about_us');?>
        </div>
    </div>
</section>
